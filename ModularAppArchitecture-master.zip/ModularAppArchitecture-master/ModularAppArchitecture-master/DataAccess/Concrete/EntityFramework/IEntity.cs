﻿namespace DataAccess.Concrete.EntityFramework
{
    public interface IEntity<T>
    {
    }
}