﻿using Core.DataAccess;
using Entities.Concrete.EntityFramework.Entities;

public interface IErrorLogDal : IEntityRepository<ErrorLog>
{
}