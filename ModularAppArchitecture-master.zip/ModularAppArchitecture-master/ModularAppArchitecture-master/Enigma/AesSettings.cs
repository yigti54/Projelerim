﻿namespace Enigma;

public class AesSettings
{
    public byte[] Key { get; set; }
    public byte[] Vektor { get; set; }
}
