﻿namespace Core.Entities
{
    public interface IDto
    {
    }
}